package com.dcfanbase.instahub.ui.util

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dcfanbase.instahub.R
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.databinding.ItemRowBinding
import com.dcfanbase.instahub.databinding.ShowInfoUserBinding
import com.dcfanbase.instahub.ui.activity.DetailActivity

class RecyleViewDataShow(val arrayData : ArrayList<ResponseAllData>) : RecyclerView.Adapter<RecyleViewDataShow.Holder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyleViewDataShow.Holder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return Holder(binding)
    }

    @RequiresApi(Build.VERSION_CODES.S)
    override fun onBindViewHolder(holder: RecyleViewDataShow.Holder, position: Int) {
        val name  = arrayData[position].login
        val imgUrl = arrayData[position].avatarUrl
        holder.bind(name,imgUrl)


        holder.binding.imgItemPhoto.setOnClickListener {
            val go = Intent(it.context,DetailActivity::class.java)
            go.putExtra(DetailActivity.KEY,arrayData[position])
            holder.binding.root.context.startActivity(go)
        }

        holder.binding.cardView.setOnLongClickListener {
            //configurasi dialog
            val bindingDialog = ShowInfoUserBinding.inflate(LayoutInflater.from(holder.binding.root.context))
            val dialog = Dialog(holder.binding.root.context)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(bindingDialog.root)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            Glide.with(holder.binding.root.context).load(imgUrl).into(bindingDialog.imgDetailUser)
            bindingDialog.tvNameDetail.text = name

            dialog.show()
            bindingDialog.topBar.setOnMenuItemClickListener{
                when(it.itemId){
                    R.id.close_menu -> {
                        dialog.dismiss()
                        true
                    }
                    else -> false
                }
            }
            true
        }
    }

    override fun getItemCount(): Int = arrayData.size

    class Holder(val binding : ItemRowBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(name : String?, imgUrl : String?){
            binding.tvItemName.text = name
            Glide.with(binding.root).load(imgUrl).into(binding.imgItemPhoto)
        }
    }

}