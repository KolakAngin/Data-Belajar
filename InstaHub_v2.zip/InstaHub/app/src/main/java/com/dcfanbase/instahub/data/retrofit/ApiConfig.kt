package com.dcfanbase.instahub.data.retrofit

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiConfig {
    private  val authInceptor = Interceptor {chain ->
        val req = chain.request()
        val requestHeader= req.newBuilder()
            .addHeader("Authorization","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")
            .build()
        chain.proceed(requestHeader)
    }

    val getService : ApiService by lazy{
        val client = OkHttpClient.Builder()
            .addInterceptor(authInceptor)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create())

            .build()
        retrofit.create(ApiService::class.java)
    }
}