package com.dcfanbase.instahub.ui.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.dcfanbase.instahub.R
import com.dcfanbase.instahub.ui.util.isAppOnline
import com.google.android.material.snackbar.Snackbar

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        if(isAppOnline(this)){
            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(this,MainActivity::class.java))
                this.finish()
            },2000L)
        }else{
            Snackbar.make(window.decorView.rootView,"Tidak ada Jaringan Internet silahkan relog",Snackbar.LENGTH_LONG).show()
        }
    }



}