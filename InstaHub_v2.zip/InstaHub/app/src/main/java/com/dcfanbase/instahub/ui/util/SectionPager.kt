package com.dcfanbase.instahub.ui.util

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dcfanbase.instahub.ui.fragment.FollowFragment

class SectionPager(activity : AppCompatActivity,val handleForUser : String) : FragmentStateAdapter(activity) {
    companion object{
        const val FOLLOWER = 0
        const val  FOLLOWING = 1
    }
    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        var fragment : Fragment = FollowFragment()

        when(position){
            FOLLOWER -> {
                fragment.arguments = Bundle().apply {
                    putString(FollowFragment.KEY_HANDLE_FOLLOW_USER,handleForUser)
                    putInt(FollowFragment.KEY_HANDLE_CODE_KEY, FOLLOWER)
                }
            }
            FOLLOWING -> {
                val bundle = Bundle()
                bundle.putString(FollowFragment.KEY_HANDLE_FOLLOW_USER,handleForUser)
                bundle.putInt(FollowFragment.KEY_HANDLE_CODE_KEY, FOLLOWING)
                fragment.arguments = bundle
            }
        }

        return fragment as Fragment
    }
}