package com.dcfanbase.instahub.ui.activity

import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dcfanbase.instahub.R
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.databinding.ActivityMainBinding
import com.dcfanbase.instahub.ui.util.MainViewModel
import com.dcfanbase.instahub.ui.util.RecyleViewDataShow
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var userSearch : String? = null
    private lateinit var recyleViewDataShow : RecyleViewDataShow
    private  val mainViewModel: MainViewModel by viewModels<MainViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding  = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mainViewModel.allDataUser.observe(this){
            setAdapterRecylceView(it)
        }
        // observer untuk all data
        mainViewModel.isLoading.observe(this){
            showLoading(it)
        }
        // observer untuk progres bar
        binding.rvMain.layoutManager = LinearLayoutManager(this)

        // logic untuk pencarian
        searchBarLogic()

        mainViewModel.nullSearchDetected.observe(this){
            notFound(it)
        }
    }

    fun setAdapterRecylceView(data : ArrayList<ResponseAllData>){
        val adapter = RecyleViewDataShow(data)
        binding.rvMain.adapter = adapter
        Log.d("mytag2","saya dalah setAdapter brody ${data[0].avatarUrl.toString()}")
    }


    fun searchBarLogic(){
        with(binding){
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, i, keyEvent ->
                    searchBar.text = searchView.text
                    searchView.hide()

                    // code untuk hanlde pencarian data user
                    val stringForSeach = searchView.text.toString()
                    if(stringForSeach.equals("")){
                        Snackbar.make(window.decorView.rootView,"tidak boleh kosong !",Snackbar.LENGTH_SHORT).show()
                    }else{
                        mainViewModel.getDataFromSearch(stringForSeach)
                        userSearch = stringForSeach
                    }

                    mainViewModel.allDataUser.observe(this@MainActivity){
                        setAdapterRecylceView(it)
                    }
                    false
                }
        }
    }

    fun notFound(decision: Boolean){
        if(decision){
            binding.imgNotFoundIcon.visibility = ImageView.VISIBLE
            binding.rvMain.visibility = RecyclerView.GONE
            binding.tvUserNotFound.text = resources.getString(R.string.not_found_user,userSearch)
            binding.tvUserNotFound.visibility = TextView.VISIBLE
        }else{
            binding.imgNotFoundIcon.visibility = ImageView.GONE
            binding.rvMain.visibility = RecyclerView.VISIBLE
            binding.tvUserNotFound.visibility = TextView.GONE
        }
    }
    fun showLoading(decision : Boolean){
        if (decision) binding.progresBar.visibility = ProgressBar.VISIBLE else binding.progresBar.visibility = ProgressBar.GONE
    }
}