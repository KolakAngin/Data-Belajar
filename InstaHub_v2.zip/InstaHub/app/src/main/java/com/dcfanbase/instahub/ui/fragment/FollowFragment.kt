package com.dcfanbase.instahub.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.databinding.FragmentFollowBinding
import com.dcfanbase.instahub.ui.util.RecyleViewDataShow
import com.dcfanbase.instahub.ui.util.SecondViewModel
import com.dcfanbase.instahub.ui.util.SectionPager

class FollowFragment() : Fragment() {

    companion object{
        const val KEY_HANDLE_FOLLOW_USER = "user_key"
        const val KEY_HANDLE_CODE_KEY = "code_key"
    }
    private lateinit var secondViewModel : SecondViewModel
    private  var _binding : FragmentFollowBinding? = null
    private val binding : FragmentFollowBinding get() = _binding!!
    private var codeKey : Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFollowBinding.inflate(inflater)
        return _binding?.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val handleForUser = arguments?.getString(KEY_HANDLE_FOLLOW_USER) as String
        codeKey = arguments?.getInt(KEY_HANDLE_CODE_KEY) as Int
        secondViewModel = ViewModelProvider(requireActivity())[SecondViewModel::class.java]
        secondViewModel.getFollowUser(handleForUser,"followers")
        secondViewModel.getFollowUser(handleForUser,"following")
        setDataFollowUser()
        secondViewModel.isloadingForListData.observe(viewLifecycleOwner){
            showLoading(it)
        }

    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    fun setDataFollow(dataUser : ArrayList<ResponseAllData>){
            binding.rvDataFollow.layoutManager = LinearLayoutManager(requireContext())
            binding.rvDataFollow.adapter = RecyleViewDataShow(dataUser)
        }

    fun setDataFollowUser(){
        when(codeKey){
            SectionPager.FOLLOWER -> {
                secondViewModel.followersUser.observe(viewLifecycleOwner){
                    setDataFollow(it)
                }
            }
            SectionPager.FOLLOWING ->{
                secondViewModel.followingUser.observe(viewLifecycleOwner){
                    setDataFollow(it)
                }
            }
        }
    }

    fun showLoading(decision : Boolean){
        if (decision) binding.progresBar.visibility = ProgressBar.VISIBLE else binding.progresBar.visibility = ProgressBar.GONE
    }
    }
