package com.dcfanbase.instahub.ui.activity

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.ProgressBar
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dcfanbase.instahub.R
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.databinding.ActivityDetailBinding
import com.dcfanbase.instahub.ui.util.SecondViewModel
import com.dcfanbase.instahub.ui.util.SectionPager
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    companion object{
        const val KEY = "key"
        const val ST1 = "Followers"
        const val ST2 = "Following"
        val arg = arrayOf(ST1, ST2)
    }
    private lateinit var binding: ActivityDetailBinding
    private val secondViewModel : SecondViewModel by viewModels<SecondViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

       //  getData key from home
        val data = if(Build.VERSION.SDK_INT >= 33){
            this.intent.getParcelableExtra<ResponseAllData>(KEY,ResponseAllData::class.java)
        }else{
            @Suppress("DEPRECATION")
            this.intent.getParcelableExtra(KEY)
        }
        Log.d("mytag2","${data?.login}")

        secondViewModel.getUser(data?.login as String)
        setAllSetup()
        val sectionPager  = SectionPager(this,data.login.toString())
        binding.viewPager.adapter = sectionPager

        TabLayoutMediator(binding.tabs,binding.viewPager){tab, position ->
            tab.text = arg[position]

        }.attach()

        supportActionBar?.elevation = 0f

        secondViewModel.isLoading.observe(this){
            showLoading(it)
        }
    }
    fun setAllSetup(){
        secondViewModel.person.observe(this@DetailActivity){
            binding.tvNameDetail.text = it.name
            binding.tvNameUser.text = it.login
            binding.follower.text = resources.getString(R.string.follower,"${it.followers}")
            binding.following.text = resources.getString(R.string.following,"${it.following}")
            Glide.with(this)
                .load(it.avatarUrl)
                .into(binding.imgDetailUser)
        }
        Log.d("mytag","saya adalah log dari setAllSetup ")
    }

    fun showLoading(decision : Boolean){
        if (decision) binding.progresBar.visibility = ProgressBar.VISIBLE else binding.progresBar.visibility = ProgressBar.GONE
    }
}