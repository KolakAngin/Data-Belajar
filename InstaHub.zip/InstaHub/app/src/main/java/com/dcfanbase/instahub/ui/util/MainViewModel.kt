package com.dcfanbase.instahub.ui.util

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.data.model.ResponseSearch
import com.dcfanbase.instahub.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {
    companion object{
        const val MYTAG = "mytag"
    }
    private val _allDataUser  = MutableLiveData<ArrayList<ResponseAllData>>()
    val allDataUser : LiveData<ArrayList<ResponseAllData>> = _allDataUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isLoading

    private val _nullSearchDetected = MutableLiveData<Boolean>(false)
    val nullSearchDetected : LiveData<Boolean> = _nullSearchDetected

    init {
        getAldataUser()
    }

    fun getAldataUser(){
        _isLoading.value = true
        val client = ApiConfig.getService.getAllUser()
        client.enqueue(object : Callback<ArrayList<ResponseAllData>>{
            override fun onResponse(
                call: Call<ArrayList<ResponseAllData>>,
                response: Response<ArrayList<ResponseAllData>>
            ) {
                if(response.isSuccessful){
                    _isLoading.value = false
                    Log.d(MYTAG,"dari MainView bisa manggil")
                    _allDataUser.value = response.body()
                    Log.d(MYTAG,"dari MainView bisa manggil dan ${allDataUser.value?.get(0)?.avatarUrl}")
                }else{
                    Log.d(MYTAG,"Response Gagal Tootal")
                }
            }

            override fun onFailure(call: Call<ArrayList<ResponseAllData>>, t: Throwable) {
                Log.d(MYTAG,t.message.toString())
            }

        })
    }
    fun getDataFromSearch(nameSearch: String){
        _isLoading.value = true
        val client = ApiConfig.getService.getDatafromSearch(nameSearch)

        client.enqueue(object : Callback<ResponseSearch>{
            override fun onResponse(
                call: Call<ResponseSearch>,
                response: Response<ResponseSearch>
            ) {
                if(response.isSuccessful){
                    _isLoading.value = false
                    val checingLenght = response.body()?.items as ArrayList<ResponseAllData>
                    if(checingLenght.size <= 0){
                        _nullSearchDetected.value = true
                    }else{
                        _allDataUser.value = checingLenght
                        _nullSearchDetected.value = false
                    }

                }else{
                    Log.d(MYTAG, response.message())
                }

                Log.d("mytag-search","${_nullSearchDetected.value}")
            }

            override fun onFailure(call: Call<ResponseSearch>, t: Throwable) {
                Log.d(MYTAG,t.message.toString())
            }
        })
    }

    fun settingNullSearch(decision: Boolean){
        _nullSearchDetected.value = false
    }
}