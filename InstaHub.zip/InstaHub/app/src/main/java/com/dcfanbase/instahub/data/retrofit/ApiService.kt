package com.dcfanbase.instahub.data.retrofit
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.data.model.ResponseSearch
import com.dcfanbase.instahub.data.model.ResponseUser
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("users")
    @Headers("Authorization: token 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")
    fun getAllUser() : Call<ArrayList<ResponseAllData>>


    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getDatafromSearch(@Query("q") q : String) : Call<ResponseSearch>


    @GET("users/{person}")
    @Headers("Authorization: token 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")
    fun getUserData(@Path("person") person: String) : Call<ResponseUser>


    @GET("users/{username}/{follow}")
    @Headers("Authorization: token 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")
    fun getFollowUser(@Path("username") username : String, @Path("follow") follow : String) : Call<ArrayList<ResponseAllData>>
}