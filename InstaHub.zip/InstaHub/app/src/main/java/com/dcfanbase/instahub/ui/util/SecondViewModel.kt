package com.dcfanbase.instahub.ui.util

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dcfanbase.instahub.data.model.ResponseAllData
import com.dcfanbase.instahub.data.model.ResponseUser
import com.dcfanbase.instahub.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SecondViewModel : ViewModel(){
    companion object{
        const val MYTAG = "mytag2"
    }
    private val _person = MutableLiveData<ResponseUser>()
    val person : LiveData<ResponseUser> = _person

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isLoading

    private val _isloadingForListData = MutableLiveData<Boolean>()
    val isloadingForListData : LiveData<Boolean> = _isloadingForListData

    private val _followerUser = MutableLiveData<ArrayList<ResponseAllData>>()
    val followersUser : LiveData<ArrayList<ResponseAllData>> = _followerUser

    private val _followingUser = MutableLiveData<ArrayList<ResponseAllData>>()
    val followingUser : LiveData<ArrayList<ResponseAllData>> = _followingUser
    fun getUser(person : String){
        _isLoading.value = true
        val client = ApiConfig.getService.getUserData(person)
        client.enqueue(object : Callback<ResponseUser> {
            override fun onResponse(call: Call<ResponseUser>, response: Response<ResponseUser>) {
                if (response.isSuccessful){
                    _isLoading.value = false
                    _person.value = response.body()
                    Log.d(MYTAG,"Response berhasil Total dari Person")
                }else{
                    Log.d(MYTAG,"Response Gagal Tootal dari Person")
                }
            }

            override fun onFailure(call: Call<ResponseUser>, t: Throwable) {
                Log.d(MYTAG,t.message.toString())
            }

        })
    }


    fun getFollowUser(user : String,follow : String){
        _isloadingForListData.value = true

        var client : Call<ArrayList<ResponseAllData>>?  = null
        if(follow.equals("followers")){
            client = ApiConfig.getService.getFollowUser(user,"followers")
        }else{
            client = ApiConfig.getService.getFollowUser(user,"following")
        }
        client.enqueue(object : Callback<ArrayList<ResponseAllData>>{
            override fun onResponse(
                call: Call<ArrayList<ResponseAllData>>,
                response: Response<ArrayList<ResponseAllData>>
            ) {
                if(response.isSuccessful){
                    if(follow.equals("followers")){
                        _isloadingForListData.value = false
                        _followerUser.value = response.body()
                    }else{
                        _followingUser.value = response.body()
                    }
                }else{
                    Log.d(MYTAG,"Response Gagal Tootal dari ${SecondViewModel::getFollowUser.name}")
                }
            }
            override fun onFailure(call: Call<ArrayList<ResponseAllData>>, t: Throwable) {
                Log.d(MYTAG,t.message.toString())
            }

        })
    }
}