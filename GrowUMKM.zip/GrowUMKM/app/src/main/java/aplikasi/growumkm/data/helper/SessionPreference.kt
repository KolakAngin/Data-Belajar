package com.example.bpaai.helper

import android.content.Context
import com.example.bpaai.data.general.Session

internal class SessionPreference(context: Context) {
    companion object {
        var PREFS_NAME = "token"
        var API_KEY_NAME = "api_key"
    }

    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    fun setToken(value: Session) {
        val editor = preferences.edit()
        editor.putString(API_KEY_NAME, value.api_key)
        editor.apply()
    }

    fun getToken(): Session {
        val model = Session()
        model.api_key = preferences.getString(API_KEY_NAME, null)
        return model
    }
}