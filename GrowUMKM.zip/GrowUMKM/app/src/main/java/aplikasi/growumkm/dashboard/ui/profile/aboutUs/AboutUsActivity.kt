package aplikasi.growumkm.dashboard.ui.profile.aboutUs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import aplikasi.growumkm.R
import aplikasi.growumkm.dashboard.ui.profile.ProfileFragment
import aplikasi.growumkm.databinding.ActivityAboutUsBinding


class AboutUsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutUsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)

        val buttonback = binding.buttonbackAU
        buttonback.setOnClickListener {
            val intent = Intent(this, ProfileFragment::class.java)
            startActivity(intent)
        }
    }


}