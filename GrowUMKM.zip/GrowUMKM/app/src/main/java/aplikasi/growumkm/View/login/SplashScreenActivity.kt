package aplikasi.growumkm.View.login

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import aplikasi.growumkm.MainActivity
import aplikasi.growumkm.R
import aplikasi.growumkm.View.Register.RegisterActivity
import aplikasi.growumkm.dashboard.ui.profile.mulaiUmkm.MulaiUmkmActivity
import aplikasi.growumkm.dashboard.ui.profile.setting.SettingActivity

@SuppressLint
@Suppress
class SplashScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashScreenActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }
}