package aplikasi.growumkm.dashboard.ui.profile.dataPribadi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import aplikasi.growumkm.R
import aplikasi.growumkm.dashboard.ui.profile.ProfileFragment
import aplikasi.growumkm.databinding.ActivityAboutUsBinding
import aplikasi.growumkm.databinding.ActivityDataPribadiBinding

class DataPribadiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDataPribadiBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_pribadi)
        val buttonback = binding.buttonbackDP
        buttonback.setOnClickListener {
            val intent = Intent(this, ProfileFragment::class.java)
            startActivity(intent)
        }
    }
}