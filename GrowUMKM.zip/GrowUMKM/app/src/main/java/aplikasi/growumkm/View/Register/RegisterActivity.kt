package aplikasi.growumkm.View.Register

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.core.view.accessibility.AccessibilityEventCompat.setAction
import aplikasi.growumkm.R
import aplikasi.growumkm.View.login.LoginActivity
import aplikasi.growumkm.data.api.ApiConfig
import aplikasi.growumkm.data.api.RegisterResponse
import aplikasi.growumkm.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {

    companion object {
        const val TAG = "registerActivity"
    }

    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.imgRegist.setImageResource(R.drawable.logogrowumkm2)

        setView()
        setAction()
        playAnimation()

        val password = binding.passwordpageregist
        val buttonback = binding.buttonback
        buttonback.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        password.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //
            }

            override fun onTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {
                setMyButtonEnable()
            }

            override fun afterTextChanged(p0: Editable?) {
                //
            }

        })

    }
    private fun setAction() {
        binding.buttonRegist.setOnClickListener {
            val name = binding.nameRegist.text.toString()
            val email = binding.emailRegist.text.toString()
            val nomer = binding.nomerRegist.text.toString()
            val kota = binding.kotaRegist.text.toString()
            val password = binding.passwordRegist.text.toString()
            when {
                name.isEmpty() -> {
                    binding.nameshaperegist.error = "Masukkan nama"
                }
                email.isEmpty() -> {
                    binding.emailshaperegist.error = "Masukkan email"
                }
                nomer.isEmpty() -> {
                    binding.Noshaperegist.error = "Masukkan nomer"
                }
                kota.isEmpty() -> {
                    binding.kotashaperegist.error = "Masukkan kota"
                }
                password.isEmpty() -> {
                    binding.Passwordshaperegist.error = "Masukkan password"
                }
                else -> {
                    register()
                }
            }
        }
    }
    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imgRegist,View.TRANSLATION_X,-30f,30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.title1SignupPage,View.ALPHA,1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(title)
            startDelay = 500
        }.start()

    }

    private fun setView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }
    private fun register() {
        showLoading(true)
        val name = binding.nameRegist.text.toString()
        val email = binding.emailRegist.text.toString()
        val nomer = binding.nomerRegist.text.toString()
        val kota = binding.kotaRegist.text.toString()
        val password = binding.passwordRegist.text.toString()

        val client = ApiConfig.getApiService().postRegister(name,email,nomer,kota,password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                val responseBody = response.body()
                showLoading(false)
                if (response.isSuccessful && responseBody != null){
                    AlertDialog.Builder(this@RegisterActivity).apply {
                        setTitle("Anda Telah Terdaftar")
                        setMessage("Silahkan klik lanjut untuk menuju ke halaman login")
                        setPositiveButton("Lanjut") {_,_ ->
                            val intent = Intent(context, LoginActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                            finish()
                        }
                        create()
                        show()
                    }
                }
                else{
                    showLoading(false)
                    Log.e(TAG,"onFailure ${response.message()}")
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG,"onFailure ${t.message}")
            }

        })


    }


    private fun setMyButtonEnable() {
        val result = binding.passwordRegist.text
        if (result != null) {
            if (result.length < 8){
                binding.buttonRegist.isEnabled = false
            }else {
                binding.buttonRegist.isEnabled = true
            }
        }

    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }

    }

}