package aplikasi.growumkm.View.login


import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View

import android.view.WindowInsets
import android.view.WindowManager
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import aplikasi.growumkm.MainActivity
import aplikasi.growumkm.R
import aplikasi.growumkm.UserPreference
import aplikasi.growumkm.View.Register.RegisterActivity
import aplikasi.growumkm.View.ViewModelFactory
import aplikasi.growumkm.data.api.LoginResponse
import aplikasi.growumkm.data.pref.UserModel
import aplikasi.growumkm.data.api.ApiConfig
import aplikasi.growumkm.databinding.ActivityLoginBinding
import retrofit2.Call
import retrofit2.Response





private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class LoginActivity : AppCompatActivity() {

    companion object{
        const val TAG = "LoginActivity"
    }

    private lateinit var LoginVM: LoginViewModel
    private lateinit var binding : ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.imgLogin.setImageResource(R.drawable.logogrowumkm1)

        setView()
        setViewModel()
        setAction()
        playAnimation()

        val password = binding.passwordLogin


        password.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //
            }

            override fun onTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {
                setMyButtonEnable()
            }

            override fun afterTextChanged(p0: Editable?) {
                //
            }

        })

    }

    private fun setView(){
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        }else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setViewModel(){
        LoginVM = ViewModelProvider(
            this, ViewModelFactory(UserPreference.getInstance(dataStore))
        )[LoginViewModel::class.java]
    }
    private fun setAction(){
        binding.buttonLogin.setOnClickListener {
            val email = binding.emailLogin.text.toString()
            val password = binding.passwordLogin.text.toString()
            when {

                email.isEmpty() -> {
                    binding.emailshapelogin.error = "Masukkan email"
                }
                password.isEmpty() -> {
                    binding.Passwordshapelogin.error = "Masukkan password"
                }
                else ->{
                    login()
                }
            }
        }

        binding.buttonRegist.setOnClickListener {
            val intent = Intent(this@LoginActivity,RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    private fun login(){
        showLoading(true)
        val email = binding.emailLogin.text.toString()
        val pasword = binding.passwordLogin.text.toString()

        val client = ApiConfig.getApiService().postLogin(email,pasword)
        client.enqueue(object : retrofit2.Callback<LoginResponse>{
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null){
                    showLoading(false)
                    LoginVM.saveUser(
                        UserModel(
                            responseBody.loginResult.name,
                            responseBody.loginResult.token,
                            isLogin = true
                        )
                    )
                    val intent = Intent(this@LoginActivity,MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                else{
                    showLoading(false)
                    Log.e(TAG,"onFailure ${response.message()}")
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG,"onFailure ${t.message}")
            }

        })
    }


    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imgLogin, View.TRANSLATION_X,-30f,30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.title1SignupPage,View.ALPHA,1f).setDuration(500)
        val btnRegist = ObjectAnimator.ofFloat(binding.buttonRegist,View.ALPHA,1f).setDuration(400)

        AnimatorSet().apply {
            playSequentially(title,btnRegist)
            startDelay = 400
        }.start()

    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }

    }

    private fun setMyButtonEnable() {
        val result = binding.passwordLogin.text
        if (result != null) {
            binding.buttonLogin.isEnabled = result.length >= 8
        }
    }


}