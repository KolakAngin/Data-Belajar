package com.example.bpaai.data.general

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Session(var api_key: String? = null) : Parcelable
