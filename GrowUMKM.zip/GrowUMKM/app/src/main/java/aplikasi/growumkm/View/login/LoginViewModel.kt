package aplikasi.growumkm.View.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import aplikasi.growumkm.UserPreference
import aplikasi.growumkm.data.pref.UserModel
import kotlinx.coroutines.launch


class LoginViewModel(private val pref : UserPreference) : ViewModel() {

    fun login(){
        viewModelScope.launch { pref.login() }
    }

    fun saveUser(user: UserModel) {
        viewModelScope.launch {
            pref.saveUser(user)
        }
    }


}